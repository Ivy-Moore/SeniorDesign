=======
History
=======

1.0.0 (2017-05-06)
------------------

* First release on PyPI.


1.0.1 (2017-05-08)
------------------

* Minor corrections in documentation

1.0.2 (2017-05-12)
------------------

* Fixed duplicate result issue
* Added language parameter
